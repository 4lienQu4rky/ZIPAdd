API Reference
=============

All non-abstract classes are available at package level, for example::

  from pyxbmct import AddonDialogWindow, Label, Button

.. autosummary::
  :toctree: _autosummary

  pyxbmct.addonwindow
  pyxbmct.addonskin
