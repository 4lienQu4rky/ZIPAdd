Links
=====

* `PyXBMCt demo addon`_
* `Kodi Python API documentation`_
* `The support thread on Kodi (XBMC) forum`_

.. _PyXBMCt demo addon: https://github.com/romanvm/pyxbmct.demo
.. _Kodi Python API documentation: http://romanvm.github.io/xbmcstubs/docs
.. _The support thread on Kodi (XBMC) forum: http://forum.xbmc.org/showthread.php?tid=174859
